import sys
from .nxpydocs import cli
def run():
    cli()